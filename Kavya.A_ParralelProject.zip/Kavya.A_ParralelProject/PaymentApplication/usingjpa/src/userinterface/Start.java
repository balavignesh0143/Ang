package userinterface;

import java.util.List;
import java.util.Scanner;

import com.cg.bank.model.Account;

import service.AccountService;
import service.AccountServiceImpl;


public class Start {
	static AccountService service=new AccountServiceImpl();
	
	public static void showMenu() {
		System.out.println("Menu:");
		System.out.println("01. Account Creation");
		System.out.println("02. Add Money to Account");
		System.out.println("03. View all account details");
		System.out.println("04. Money Transfer");
		System.out.println("05. View All Accounts");
		System.out.println("06. Exit");
		System.out.print("Enter Your Choice : ");
	}
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		int choice;
		boolean result;
		while(true)
		{
			showMenu();
			
			choice = scanner.nextInt();
			switch(choice)
			{
			case 1:
			
				System.out.println("Account Creation");
				try
				{
					Account user=new Account();
					System.out.println("Enter your name:");
					user.setName(scanner.next());
					System.out.println("Enter your phone number:");
					user.setPhoneNumber(scanner.nextLong());
					System.out.println("Enter your email:");
					user.setEmailId(scanner.next());
					user.setBalance(0);
					service.createAccount(user);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 2:
				
				System.out.println("Adding Money");
				try {
					System.out.println("Enter the account number to add money:");
					int AccountNumber=scanner.nextInt();
					System.out.println("Enter the amount to be added in the account"+AccountNumber);
					int Amount=scanner.nextInt();
					result=service.addMoney(AccountNumber, Amount);
					if(result) {
						System.out.println("Money added successfully");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
			
				System.out.println("View Account Details");
				try
				{
					System.out.println("Enter the Account Number");
					int AccountNumber=scanner.nextInt();
					Account user=service.viewAccount(AccountNumber);
					System.out.println("Name="+user.getName()+"\nPhone="+user.getPhoneNumber()+"\nEmail="+user.getEmailId()+"\nBalance="+user.getBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				
				System.out.println("Money Transfer");
				try
				{
					System.out.println("Enter the sender Account Number");
					int SenderAccountNumber=scanner.nextInt();
					System.out.println("Enter the Reciever Account Number");
					int RecieverAccountNumber=scanner.nextInt();
					System.out.println("Enter the amount to be transferred");
					int TransferAmount=scanner.nextInt();
					result=service.transfer(SenderAccountNumber, RecieverAccountNumber, TransferAmount);
					if(result) {
						System.out.println("Money transfered successfully");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 5:
			
				System.out.println("All Accounts:\n");
				try
				{	
					List<Account> list=service.getAllAccounts();
					for (Account account : list) {
						System.out.println("Account Number: "+account.getAccountNumber()+"\t\tName: "+account.getName());
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				service.closeFactory();
				System.exit(0);
			default:
				break;
			}
		}
	}

}
