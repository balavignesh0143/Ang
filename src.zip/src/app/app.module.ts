import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplayallComponent } from './displayall/displayall.component';
import { CustomeraddComponent } from './customeradd/customeradd.component';
import { LoginComponent } from './login/login.component';
import { HomepageComponent } from './homepage/homepage.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { ShowbalanceComponent } from './showbalance/showbalance.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
import { CustomerServiceService } from './customer-service.service';

@NgModule({
  declarations: [
    AppComponent,
    DisplayallComponent,
    CustomeraddComponent,
    LoginComponent,
    HomepageComponent,
    DepositComponent,
    WithdrawComponent,
    ShowbalanceComponent,
    FundtransferComponent,
    PrintTransactionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,CustomerServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
