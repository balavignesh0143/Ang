import { Component, OnInit } from '@angular/core';
import { Customer, Transactions, CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  isLogin:boolean=true;
  customer:Customer[]=[];
  createdTransaction:Transactions;
  router:Router;
  service:CustomerServiceService;
  constructor(service:CustomerServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  depositeAmount(data:any){
    let tid:number;
    let caccount_first=data.caccount;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Deposite Amount"
    this.service.depositeBalance(caccount_first,cbalance);
    this.createdTransaction=new Transactions("123",data.caccount,"",data.cbalance,ttype);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['app-homepage']);
  }


  ngOnInit() {
    this.customer=this.service.getCustomer();
  }

}
