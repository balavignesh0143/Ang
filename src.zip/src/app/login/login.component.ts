import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerServiceService, Customer } from '../customer-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  service:CustomerServiceService;
  router:Router;

  constructor(service:CustomerServiceService,router:Router) {
    this.service=service;
    this.router=router;
   }

   customer:Customer[]=[];

   isLogin:boolean=true;
  login(data:any){
    if(this.service.login(data)){
      this.isLogin=this.service.isLogin;
      this.router.navigate(['app-homepage']);
    }else{
      alert("Values does not matched!")
    }
  }

  ngOnInit() {
    this.service.fetchCustomer();
    this.customer=this.service.getCustomer();
  }

}
