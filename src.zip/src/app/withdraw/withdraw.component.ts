import { Component, OnInit } from '@angular/core';
import { Customer, Transactions, CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  isLogin:boolean=true;
  customer:Customer[]=[];
  createdTransaction:Transactions;
  router:Router;
  service:CustomerServiceService;
  constructor(service:CustomerServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  withdrawAmount(data:any){
    let caccount_first=data.caccount;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Withdraw Amount"
    this.service.withdrawBalance(caccount_first,cbalance);
    this.createdTransaction=new Transactions("123",data.caccount,"",data.cbalance,ttype);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['app-homepage']);
  }

  ngOnInit() {
    this.customer=this.service.getCustomer();
  }

}
