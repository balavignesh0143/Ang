import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { CustomeraddComponent } from './customeradd/customeradd.component';
import { DisplayallComponent } from './displayall/displayall.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
import { ShowbalanceComponent } from './showbalance/showbalance.component';


const routes: Routes = [
  {
    path:'app-homepage',
    component : HomepageComponent
  },
  {
    path:'app-login',
    component : LoginComponent
  },
  {
    path:'app-customeradd',
    component : CustomeraddComponent
  },
  {
    path:'app-displayall',
    component : DisplayallComponent
  },
  {
    path:'app-deposit',
    component : DepositComponent
  },
  {
    path:'app-withdraw',
    component : WithdrawComponent
  },
  {
    path:'app-fundtransfer',
    component : FundtransferComponent
  },
  {
    path:'app-print-transaction',
    component : PrintTransactionComponent
  },
  {
    path:'app-showbalance',
    component : ShowbalanceComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
